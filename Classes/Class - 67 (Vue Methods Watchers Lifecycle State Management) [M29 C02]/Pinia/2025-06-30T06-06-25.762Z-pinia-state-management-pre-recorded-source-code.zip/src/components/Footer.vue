<script setup>
</script>

<template>
    <footer class="bg-dark text-white text-center py-3 mt-auto">
      <p class="mb-0">&copy; 2025 Vue App. All rights reserved.</p>
    </footer>
</template>

<style scoped>
</style>