<script setup>
</script>

<template>
    <ul>
        <li>Apple</li>
        <li>Banana</li>
        <li>Mangoo</li>
    </ul>
</template>

<style scoped>
</style>