<script setup>
</script>

<template>
      <div class="container py-5 text-center">
        <h2>ℹ️ About Page Modify</h2>
        <p>This is the about page of our Vue app using Bootstrap.</p>
      </div>
</template>

<style scoped>
</style>